﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPractice
{
    internal class  Steps
    {
        //Data member
        private string recipeSteps;

        //Properties
        public string RecipeSteps
        {  
            get { return recipeSteps; }
            set {  recipeSteps = value; }
        }
    }
}
