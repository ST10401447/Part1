# Part1
The application is used to enter the recipe that contain  details of ingredients and steps.After entering the details  the user can display the full recipe which include both ingredients and steps,the user can choose whether he/she wants the quantity scale to display as the original scale,half,double or triple.After entering a recipe the user can also select exit to add a new recipe or any other key to exit the program

Steps:1.The user is asked to press capital Y if they want to enter recipe and any other key to exit
      2.The user is requested to ask how many ingredients they want to insert
      3.The user is requested to enter the quantity for the ingredient
      4.The user is requested to enter the unit measurement for the ingredient
      5.The user should enter the number of steps to follow
      6.The user is requested to enter the steps
      7.The munu is displayed and the user has to choose an option which the first one is the user request the recipe to be displayed with the original scale,second option is to dispaly the recipe with half the scale a user inserted on the original,The third option is to display the recipe with a double quantity scale and the forth option is to display the recipe with a  tripled quantity scale ,Lastly the last option is to exit which then ask if the user wants to enter a new recipe or exit.If the user wants to exit he /she should press any button but if they want to enter new recipe they should enter capital letter Y.
