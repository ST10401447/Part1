﻿using ArrayPractice;
using System.Security.Cryptography.X509Certificates;

internal class Program
{
    private static void Main(string[] args)
    {
        //Declaration to enter new recipe and Taking input
        string yes;
        Console.Write("Enter Y if you want to  to enter a  recipe  or any key to exit:");
        yes = Console.ReadLine();
         
        
        while (yes == "Y")
        {
            //Declaration for ingredients
            int ingredientsNo =0;
            try
            {
             //Taking user inputs 
                Console.Write("Enter the number of ingredients :");
                ingredientsNo = Convert.ToInt32(Console.ReadLine());
            }catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Declaration of array of recipe object
            Recipe[] recipe = new Recipe[ingredientsNo];


            for (int i = 0; i < recipe.Length; i++)
            {
                recipe[i] = new Recipe();
                Console.Write("Enter the name for the ingredient :");
                recipe[i].IngredientName = Console.ReadLine();
                try
                {
                    Console.Write("Enter the ingredient quantity :");
                    recipe[i].Quantity = Convert.ToDouble(Console.ReadLine());

                }catch(Exception ex) {
                    Console.WriteLine(ex.Message); 
                }

                Console.Write("Enter the unit  for the ingredient :");
                recipe[i].Unit = Console.ReadLine();
            }
            //Declaration for steps
            int stepsNo=0;
            try
            {
                //Taking inputs for steps
                Console.Write("Enter the number of steps :");
                stepsNo = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);  
            }
            //Declarations of array of steps object
            Steps[] steps = new Steps[stepsNo];

            for (int i = 0; i < steps.Length; i++)
            {
                steps[i] = new Steps();
                Console.Write("Enter the steps for the recipe :");
                steps[i].RecipeSteps = Console.ReadLine();
            }

            //Displaying the menu with options for users
            int choice = 0;
            try
            {
                Console.WriteLine("----------------------------------------------------------------------");
                Console.Write("The menu is : \n"
                              + "1.Dispaly the recipe with the original scale\n"
                              + "2.Dispay the recipe with a scaled factor of half \n"
                              + "3.4.Dispay the recipe with a scaled factor of double \n"
                              + "4.Dispay the recipe with  a scaled factor of triple \n"
                              + "5.Exit \n");

                //Requesting user's choice
                Console.WriteLine("------------------------------------------");
                Console.Write("Enter your choice :");
                choice = Convert.ToInt32(Console.ReadLine());
            }catch(Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            while (choice != 5)
            {
                switch (choice)
                {
                   
                    
                    case 1:
                        for (int j = 0; j < recipe.Length; j++)
                        {
                            Console.WriteLine($"The name of ingredient {j + 1} is " + recipe[j].IngredientName);
                            Console.WriteLine($"The quantity of ingredient {j + 1} is " + recipe[j].Quantity);
                            Console.WriteLine($"The unit of the ingredient {j + 1} is " + recipe[j].Unit);
                        }
                        for (int k = 0; k < steps.Length; k++)
                        {
                            Console.WriteLine($"Step{k + 1} is to " + steps[k].RecipeSteps);
                        }
                        try
                        {

                            Console.WriteLine("----------------------------------------------------------------------");
                            Console.Write("The menu is : \n"
                              + "1.Dispaly the recipe with the original scale\n"
                              + "2.Dispay the recipe with a scaled factor of half \n"
                              + "3.4.Dispay the recipe with a scaled factor of double \n"
                              + "4.Dispay the recipe with  a scaled factor of triple \n"
                              + "5.Exit \n");

                            Console.Write("Enter your choice :");
                            choice = Convert.ToInt32(Console.ReadLine());
                        }catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 2:
                        for (int j = 0; j < recipe.Length; j++)
                        {
                            Console.WriteLine($"The name of the ingredient {j + 1}  is "  + recipe[j].IngredientName);
                            Console.WriteLine($"The quantity of the ingredient {j + 1} is " + recipe[j].Quantity * 0.5);
                            Console.WriteLine($"The unit of the ingredient {j + 1} is "  + recipe[j].Unit);
                        }
                        for (int k = 0; k < steps.Length; k++)
                        {
                            Console.WriteLine($"Step{k + 1} is to " + steps[k].RecipeSteps);
                        }
                        try
                        {

                            Console.WriteLine("----------------------------------------------------------------------");
                            Console.Write("The menu is : \n"
                                     + "1.Dispaly the recipe with the original scale\n"
                                     + "2.Dispay the recipe with a scaled factor of half \n"
                                     + "3.4.Dispay the recipe with a scaled factor of double \n"
                                     + "4.Dispay the recipe with  a scaled factor of triple \n"
                                     + "5.Exit \n");

                            Console.WriteLine("------------------------------------------");
                            Console.Write("Enter your choice : ");
                            choice = Convert.ToInt32(Console.ReadLine());
                        }catch(Exception ex) {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 3:
                        for (int j = 0; j < recipe.Length; j++)
                        {
                            Console.WriteLine($"The name of the ingredient {j + 1} is " + recipe[j].IngredientName);
                            Console.WriteLine($"The quantity of the ingredient {j + 1} is " + recipe[j].Quantity * 2);
                            Console.WriteLine($"The unit of the ingredient {j + 1} is " + recipe[j].Unit);
                        }
                        for (int k = 0; k < steps.Length; k++)
                        {
                            Console.WriteLine($"Step{k + 1} is to " + steps[k].RecipeSteps);
                        }
                        try
                        {

                            Console.WriteLine("----------------------------------------------------------------------");
                            Console.Write("The menu is : \n"
                                        + "1.Dispaly the recipe with the original scale\n"
                                        + "2.Dispay the recipe with a scaled factor of half \n"
                                        + "3.4.Dispay the recipe with a scaled factor of double \n"
                                        + "4.Dispay the recipe with  a scaled factor of triple \n"
                                        + "5.Exit \n");
                            Console.WriteLine("------------------------------------------");
                            Console.Write("Enter your choice :");
                            choice = Convert.ToInt32(Console.ReadLine());
                        }catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        break;

                    case 4:
                        for (int j = 0; j < recipe.Length; j++)
                        {
                            Console.WriteLine($"The name of the ingredient {j + 1} is " + recipe[j].IngredientName);
                            Console.WriteLine($"The quantity of the ingredient {j + 1} is " + recipe[j].Quantity * 3);
                            Console.WriteLine($"The unit of the ingredient {j + 1} is " + recipe[j].Unit, j + 1);
                        }

                        for (int k = 0; k < steps.Length; k++)
                        {
                            Console.WriteLine($"Step{k + 1} is to " + steps[k].RecipeSteps);
                        }
                        try
                        {

                            Console.WriteLine("----------------------------------------------------------------------");
                            Console.Write("The menu is \n"
                                             + "1.Dispaly the recipe with the original scale \n"
                                             + "2.Dispay the recipe with a scaled factor of half \n"
                                             + "3.4.Dispay the recipe with a scaled factor of double \n"
                                             + "4.Dispay the recipe with  a scaled factor of triple \n"
                                             + "5.Exit\n");

                            Console.WriteLine("------------------------------------------");
                            Console.Write("Enter your choice :");
                            choice = Convert.ToInt32(Console.ReadLine());
                        }catch(Exception ex) {
                            Console.WriteLine(ex.Message);
                                }
                        break;
                    case 5:
                    default:
                        choice = 5;
                        break;
                }

            } 
            //Asking if tge user want to enter a new recipe or exit
            Console.Write("Enter Y if you want to  to enter a new recipe  or any key to exit:");
            yes = Console.ReadLine();
        }
        Console.WriteLine("Thank you for using our system BYE!!!!!!");


        }
    }
