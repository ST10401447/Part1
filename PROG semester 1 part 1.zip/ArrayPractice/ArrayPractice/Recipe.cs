﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPractice
{
    internal class Recipe
    {
        //Data members
        private string ingredientname;
        private double quantity;
        private string unit;
        
        //Properties
        public string IngredientName 
        { 
            get { return ingredientname; }
            set { ingredientname = value; }
        }
        public double Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
        public string Unit
        {
            get { return unit; }
            set { unit = value; }
        }
        
    }
 
}
